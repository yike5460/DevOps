"use strict";Object.defineProperty(exports,"__esModule",{value:!0}),exports.FARGATE_PROFILE_RESOURCE_TYPE=exports.CLUSTER_RESOURCE_TYPE=void 0,exports.CLUSTER_RESOURCE_TYPE="Custom::AWSCDK-EKS-Cluster",exports.FARGATE_PROFILE_RESOURCE_TYPE="Custom::AWSCDK-EKS-FargateProfile";
//# sourceMappingURL=consts.js.map
